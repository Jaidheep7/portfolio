import { useLanguage } from '../context/LanguageContext';
import content from '../data/content';
import ScrollReveal from './ScrollReveal';

export default function Languages() {
  const { language } = useLanguage();
  const t = content[language].languages;
  const isJP = language === 'jp';

  return (
    <section id="languages" className="section-padding">
      <div className="max-w-5xl mx-auto">
        <ScrollReveal>
          <h2 className={`section-title ${isJP ? 'font-japanese' : ''}`}>{t.title}</h2>
        </ScrollReveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          {t.items.map((lang, index) => (
            <ScrollReveal key={index} delay={index * 150}>
              <div className="glass-card text-center group">
                {/* Circular Progress */}
                <div className="relative w-24 h-24 mx-auto mb-4">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50" cy="50" r="42"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="4"
                      className="text-beige dark:text-dark-border"
                    />
                    <circle
                      cx="50" cy="50" r="42"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="4"
                      strokeLinecap="round"
                      className="text-accent transition-all duration-1000 ease-out"
                      strokeDasharray={`${lang.proficiency * 2.64} ${264 - lang.proficiency * 2.64}`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-bold">{lang.proficiency}%</span>
                  </div>
                </div>

                <h3 className={`font-bold text-base mb-1 ${isJP ? 'font-japanese text-sm' : ''}`}>
                  {lang.name}
                </h3>
                <p className={`text-xs text-warmgray ${isJP ? 'font-japanese' : ''}`}>
                  {lang.level}
                </p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
