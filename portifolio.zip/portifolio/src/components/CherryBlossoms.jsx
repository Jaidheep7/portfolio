import { useEffect, useState } from 'react';

function Petal({ id }) {
  const [style] = useState(() => {
    const left = Math.random() * 100;
    const delay = Math.random() * 8;
    const duration = 6 + Math.random() * 6;
    const size = 10 + Math.random() * 14;
    const drift = -30 + Math.random() * 60;
    const rotation = Math.random() * 360;

    return {
      left: `${left}%`,
      animationDelay: `${delay}s`,
      animationDuration: `${duration}s`,
      width: `${size}px`,
      height: `${size}px`,
      '--drift': `${drift}px`,
      '--rotation': `${rotation}deg`,
    };
  });

  return (
    <div className="cherry-petal" style={style}>
      <svg viewBox="0 0 20 20" className="w-full h-full">
        <ellipse cx="10" cy="10" rx="6" ry="10" fill="rgba(255, 183, 197, 0.7)" />
        <ellipse cx="10" cy="10" rx="3" ry="8" fill="rgba(255, 150, 170, 0.5)" />
      </svg>
    </div>
  );
}

export default function CherryBlossoms() {
  const [petals, setPetals] = useState([]);

  useEffect(() => {
    const petalArray = Array.from({ length: 25 }, (_, i) => i);
    setPetals(petalArray);
  }, []);

  return (
    <div className="cherry-container">
      {petals.map((id) => (
        <Petal key={id} id={id} />
      ))}
    </div>
  );
}
