import { useState, useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import content from '../data/content';

export default function Navbar() {
  const { language, toggleLanguage } = useLanguage();
  const { isDark, toggleTheme } = useTheme();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = content[language].nav;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: t.home, href: '#home' },
    { label: t.experience, href: '#experience' },
    { label: t.projects, href: '#projects' },
    { label: t.skills, href: '#skills' },
    { label: t.languages, href: '#languages' },
    { label: t.achievements, href: '#achievements' },
    { label: t.contact, href: '#contact' },
  ];

  const handleResumeDownload = () => {
    const path = content[language].hero.resumePath;
    const link = document.createElement('a');
    link.href = path;
    link.download = language === 'en' ? 'Resume_EN.pdf' : 'Resume_JP.pdf';
    link.click();
  };

  const scrollTo = (href) => {
    setMobileMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'glass shadow-sm py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a
          href="#home"
          onClick={(e) => { e.preventDefault(); scrollTo('#home'); }}
          className={`text-lg font-bold tracking-tight transition-colors ${
            language === 'jp' ? 'font-japanese' : ''
          }`}
        >
          {language === 'en' ? 'DJ' : 'ジャイディープ'}
          <span className="text-accent">.</span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => { e.preventDefault(); scrollTo(item.href); }}
              className={`px-3 py-2 text-sm rounded-lg transition-all duration-200 hover:bg-black/5 dark:hover:bg-white/5 ${
                language === 'jp' ? 'font-japanese text-xs' : ''
              }`}
            >
              {item.label}
            </a>
          ))}

          {/* Resume Button */}
          <button
            onClick={handleResumeDownload}
            className={`px-3 py-2 text-sm rounded-lg transition-all duration-200 hover:bg-black/5 dark:hover:bg-white/5 text-accent font-medium ${
              language === 'jp' ? 'font-japanese text-xs' : ''
            }`}
          >
            📄 {t.resume}
          </button>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-3">
          {/* Dark Mode Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-all duration-200"
            aria-label="Toggle dark mode"
          >
            {isDark ? (
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
              </svg>
            )}
          </button>

          {/* Language Toggle */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5 transition-all duration-200 text-sm font-medium"
            aria-label="Toggle language"
          >
            <span className={`transition-opacity duration-200 ${language === 'en' ? 'opacity-100' : 'opacity-50'}`}>🇺🇸</span>
            <span className="text-xs text-warmgray">/</span>
            <span className={`transition-opacity duration-200 ${language === 'jp' ? 'opacity-100' : 'opacity-50'}`}>🇯🇵</span>
          </button>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-all"
            aria-label="Toggle menu"
          >
            <div className="w-5 h-4 flex flex-col justify-between">
              <span className={`block h-0.5 bg-current transition-all duration-300 ${mobileMenuOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
              <span className={`block h-0.5 bg-current transition-all duration-300 ${mobileMenuOpen ? 'opacity-0' : ''}`} />
              <span className={`block h-0.5 bg-current transition-all duration-300 ${mobileMenuOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden overflow-hidden transition-all duration-300 ${
          mobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-6 py-4 space-y-1 glass mt-2 mx-4 rounded-2xl">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => { e.preventDefault(); scrollTo(item.href); }}
              className={`block px-4 py-2.5 text-sm rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-all ${
                language === 'jp' ? 'font-japanese' : ''
              }`}
            >
              {item.label}
            </a>
          ))}
          <button
            onClick={() => { handleResumeDownload(); setMobileMenuOpen(false); }}
            className={`block w-full text-left px-4 py-2.5 text-sm rounded-xl text-accent font-medium hover:bg-black/5 dark:hover:bg-white/5 transition-all ${
              language === 'jp' ? 'font-japanese' : ''
            }`}
          >
            📄 {t.resume}
          </button>
        </div>
      </div>
    </nav>
  );
}
