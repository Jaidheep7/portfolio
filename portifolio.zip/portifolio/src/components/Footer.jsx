import { useLanguage } from '../context/LanguageContext';
import content from '../data/content';

export default function Footer() {
  const { language } = useLanguage();
  const t = content[language].footer;
  const isJP = language === 'jp';

  return (
    <footer className="py-8 px-6 border-t border-beige/50 dark:border-dark-border">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className={`text-sm text-warmgray ${isJP ? 'font-japanese text-xs' : ''}`}>
          {t.text}
        </p>

      </div>
    </footer>
  );
}
