import { useLanguage } from '../context/LanguageContext';
import content from '../data/content';
import ScrollReveal from './ScrollReveal';

export default function WorkExperience() {
  const { language } = useLanguage();
  const t = content[language].experience;
  const isJP = language === 'jp';

  return (
    <section id="experience" className="section-padding bg-cream/30 dark:bg-dark-surface/30">
      <div className="max-w-5xl mx-auto">
        <ScrollReveal>
          <h2 className={`section-title ${isJP ? 'font-japanese' : ''}`}>{t.title}</h2>
        </ScrollReveal>

        <div className="relative mt-12">
          {/* Timeline Line */}
          <div className="absolute left-0 md:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-accent via-beige to-transparent dark:from-accent dark:via-dark-border" />

          {t.items.map((item, index) => (
            <ScrollReveal key={index} delay={index * 150}>
              <div className="relative pl-8 md:pl-20 pb-12 last:pb-0 group">
                {/* Timeline Dot */}
                <div className="absolute left-0 md:left-8 top-1 -translate-x-1/2 w-3 h-3 rounded-full bg-accent border-4 border-white dark:border-dark-bg transition-all group-hover:scale-125 group-hover:bg-charcoal dark:group-hover:bg-accent" />

                <div className="glass-card">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-3">
                    <div>
                      <h3 className={`text-lg font-bold ${isJP ? 'font-japanese' : ''}`}>
                        {item.role}
                      </h3>
                      <p className={`text-accent font-medium text-sm ${isJP ? 'font-japanese' : ''}`}>
                        {item.company}
                      </p>
                    </div>
                    <span className={`text-xs text-warmgray mt-1 md:mt-0 whitespace-nowrap ${isJP ? 'font-japanese' : ''}`}>
                      {item.duration}
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {item.responsibilities.map((resp, i) => (
                      <li key={i} className={`text-sm text-warmgray flex items-start gap-2 ${isJP ? 'font-japanese text-xs' : ''}`}>
                        <span className="text-accent mt-1 shrink-0">▸</span>
                        {resp}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
