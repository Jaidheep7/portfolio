import { useLanguage } from '../context/LanguageContext';
import content from '../data/content';
import ScrollReveal from './ScrollReveal';

export default function Achievements() {
  const { language } = useLanguage();
  const t = content[language].achievements;
  const isJP = language === 'jp';

  return (
    <section id="achievements" className="section-padding bg-cream/30 dark:bg-dark-surface/30">
      <div className="max-w-5xl mx-auto">
        <ScrollReveal>
          <h2 className={`section-title ${isJP ? 'font-japanese' : ''}`}>{t.title}</h2>
        </ScrollReveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-12">
          {t.items.map((item, index) => (
            <ScrollReveal key={index} delay={index * 100}>
              <div className="glass-card group relative overflow-hidden h-full">
                {/* Badge icon */}
                <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <svg className="w-12 h-12 text-accent" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                </div>

                <div className="flex items-start gap-3">
                  {/* Badge */}
                  <div className="w-10 h-10 shrink-0 rounded-xl bg-accent/10 dark:bg-accent/20 flex items-center justify-center">
                    <svg className="w-5 h-5 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                    </svg>
                  </div>

                  <div>
                    <h3 className={`font-bold text-sm leading-tight mb-1 ${isJP ? 'font-japanese text-xs' : ''}`}>
                      {item.title}
                    </h3>
                    <p className={`text-xs text-warmgray ${isJP ? 'font-japanese' : ''}`}>
                      {item.organization}
                    </p>
                    <p className={`text-xs text-accent mt-1 ${isJP ? 'font-japanese' : ''}`}>
                      {item.date}
                    </p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
