import { useLanguage } from '../context/LanguageContext';
import content from '../data/content';

export default function Hero() {
  const { language } = useLanguage();
  const t = content[language].hero;
  const isJP = language === 'jp';

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = t.resumePath;
    link.download = language === 'en' ? 'Resume_EN.pdf' : 'Resume_JP.pdf';
    link.click();
  };

  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative overflow-hidden bg-pattern"
    >
      {/* Decorative Elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-accent/10 rounded-full blur-3xl animate-pulse-soft" />
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-beige/30 dark:bg-accent/5 rounded-full blur-3xl animate-pulse-soft animate-delay-300" />
      <div className="absolute top-1/3 left-1/4 w-2 h-2 bg-accent/40 rounded-full animate-float" />
      <div className="absolute top-2/3 right-1/3 w-1.5 h-1.5 bg-warmgray/30 rounded-full animate-float animate-delay-200" />

      <div className="relative z-10 text-center px-6 max-w-3xl mx-auto pt-20">
        {/* Profile Photo */}
        <div className="mb-8 animate-fade-in">
          <div className="w-40 h-40 mx-auto rounded-full bg-gradient-to-br from-accent/30 to-beige dark:from-accent/20 dark:to-dark-border p-1 animate-float shadow-lg">
            <div className="w-full h-full rounded-full overflow-hidden">
              <img
                src="/profile.jpg"
                alt="Dasari Jaidheep"
                className="w-full h-full object-cover object-top"
              />
            </div>
          </div>
        </div>

        {/* Text */}
        <div className="animate-fade-in animate-delay-100">
          <p className={`text-sm tracking-[0.2em] uppercase text-warmgray mb-4 ${isJP ? 'font-japanese' : ''}`}>
            {t.greeting}
          </p>
        </div>

        <div className="animate-fade-in animate-delay-200">
          <h1 className={`text-5xl md:text-7xl font-bold mb-4 tracking-tight ${isJP ? 'font-japanese text-4xl md:text-6xl' : ''}`}>
            {t.name}
          </h1>
        </div>

        <div className="animate-fade-in animate-delay-300">
          <p className={`text-lg md:text-xl text-accent font-medium mb-6 ${isJP ? 'font-japanese text-base' : ''}`}>
            {t.tagline}
          </p>
        </div>

        <div className="animate-fade-in animate-delay-400">
          <p className={`text-warmgray max-w-xl mx-auto mb-10 leading-relaxed ${isJP ? 'font-japanese text-sm' : 'text-base'}`}>
            {t.subtitle}
          </p>
        </div>

        <div className="animate-fade-in animate-delay-500">
          <button onClick={handleDownload} className={`btn-primary ${isJP ? 'font-japanese' : ''}`}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            {t.downloadResume}
          </button>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-fade-in animate-delay-500">
          <div className="w-6 h-10 rounded-full border-2 border-warmgray/30 flex justify-center pt-2">
            <div className="w-1 h-2 bg-warmgray/50 rounded-full animate-float" />
          </div>
        </div>
      </div>
    </section>
  );
}
