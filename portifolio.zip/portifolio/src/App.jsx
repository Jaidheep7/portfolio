import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { ThemeProvider } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import WorkExperience from './components/WorkExperience';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Languages from './components/Languages';
import Achievements from './components/Achievements';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CherryBlossoms from './components/CherryBlossoms';

function AppContent() {
  const { language } = useLanguage();
  const isJP = language === 'jp';

  return (
    <div
      key={language}
      className={`min-h-screen transition-colors duration-500 relative ${
        language === 'jp' ? 'font-japanese' : 'font-sans'
      }`}
    >
      {/* Cherry Blossoms — only visible in Japanese mode */}
      {isJP && <CherryBlossoms />}

      <Navbar />
      <main className="animate-fade-in">
        <Hero />
        <WorkExperience />
        <Projects />
        <Skills />
        <Languages />
        <Achievements />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </ThemeProvider>
  );
}
