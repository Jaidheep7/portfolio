const content = {
  en: {
    nav: {
      home: 'Home',
      experience: 'Experience',
      projects: 'Projects',
      skills: 'Skills',
      languages: 'Languages',
      achievements: 'Achievements',
      contact: 'Contact',
      resume: 'Resume',
    },
    hero: {
      greeting: 'Hello, I am',
      name: 'Dasari Jaidheep',
      tagline: 'AI & ML Enthusiast | Full-Stack Web Developer',
      subtitle: 'B.Tech CSE student at SRM University AP, passionate about Artificial Intelligence, Machine Learning, and building elegant web experiences. Seeking opportunities to contribute to innovative teams in Japan.',
      downloadResume: 'Download Resume',
      resumePath: '/resumes/resume_en.pdf',
    },
    experience: {
      title: 'Experience',
      items: [
        {
          company: 'SRM University AP',
          role: 'Research Intern',
          duration: 'Jul 2025 — Present',
          responsibilities: [
            'Working under a faculty mentor on Social Network Analysis using Graph Neural Networks (GNNs)',
            'Conducting research on node relationships and network behavior',
            'Collaborating in a small research team and contributing to analysis and implementation',
          ],
        },
        {
          company: 'InternPe',
          role: 'Web Development Intern',
          duration: 'Nov 2023 — Dec 2023',
          responsibilities: [
            'Designed and developed responsive web pages using HTML and CSS',
            'Improved UI/UX and website functionality',
            'Gained hands-on experience with real-world front-end development',
          ],
        },
        {
          company: 'ISKCON Vijayawada',
          role: 'Social Impact Intern',
          duration: 'Mar 2025',
          responsibilities: [
            'Participated in community awareness programs focused on sustainability',
            'Engaged with local communities and contributed to social responsibility initiatives',
          ],
        },
        {
          company: 'SRM University AP',
          role: 'Community Engagement Project Lead',
          duration: 'Jan 2023',
          responsibilities: [
            'Led a team of 4 members to identify and solve a real-life problem in a local factory',
            'Focused on teamwork, leadership, and practical problem-solving',
          ],
        },
      ],
    },
    projects: {
      title: 'Projects',
      items: [
        {
          title: 'Social Network Analysis using GNNs',
          description: 'Research-oriented project focusing on analyzing complex social networks. Applied Graph Neural Networks to study relationships and patterns within network data.',
          techStack: ['Python', 'Graph Neural Networks', 'NetworkX', 'PyTorch'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: 'Expense Tracker Web Application',
          description: 'A web application for tracking expenses and managing budgets. Features expense logging, budget analysis, data visualization, secure authentication, and responsive design.',
          techStack: ['React.js', 'Node.js', 'MongoDB', 'JavaScript', 'CSS'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: 'Recipe Management Platform',
          description: 'A web-based platform to explore, share, and manage food recipes. Enables searching and filtering recipes based on ingredients, cuisine, and dietary preferences.',
          techStack: ['HTML', 'CSS', 'JavaScript', 'Node.js', 'MySQL'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: 'Library Management System',
          description: 'Designed a system to manage library inventory and track issued and returned books. Maintains real-time records of book availability and usage.',
          techStack: ['Python', 'MySQL', 'HTML', 'CSS'],
          github: 'https://github.com/Jaidheep7',
        },
      ],
    },
    skills: {
      title: 'Skills',
      categories: [
        {
          name: 'Programming Languages',
          items: ['Python', 'C', 'C++'],
        },
        {
          name: 'Web & Database Technologies',
          items: ['HTML', 'CSS', 'JavaScript', 'React.js', 'Node.js', 'MongoDB', 'MySQL'],
        },
        {
          name: 'AI & Related Technologies',
          items: ['Machine Learning', 'Computer Vision', 'Graph Neural Networks (GNNs)'],
        },
        {
          name: 'Tools & Platforms',
          items: ['Git', 'Linux'],
        },
      ],
    },
    languages: {
      title: 'Languages Known',
      items: [
        { name: 'English', level: 'Fluent', proficiency: 90 },
        { name: 'Telugu', level: 'Native', proficiency: 100 },
        { name: 'Hindi', level: 'Professional Proficiency', proficiency: 80 },
        { name: 'Japanese', level: 'JLPT N4 (Target: N3)', proficiency: 45 },
      ],
    },
    achievements: {
      title: 'Achievements & Certifications',
      items: [
        {
          title: 'MongoDB Certified Associate Developer',
          organization: 'MongoDB University',
          date: '2025',
        },
        {
          title: 'TOMIDAI Global SciFrontiers Program',
          organization: 'University of Toyama, Japan',
          date: '2025',
        },
        {
          title: 'The Joy of Computing Using Python (NPTEL)',
          organization: 'IIT Madras',
          date: '2023',
        },
        {
          title: 'National Level Archery — 10th Place',
          organization: 'National Competition',
          date: '2017',
        },
        {
          title: 'Certificate of Excellence — Nationwide Olympiad',
          organization: 'Government of Andhra Pradesh',
          date: '2014',
        },
        {
          title: 'Winner — University Online Game Competition',
          organization: 'SRM University AP',
          date: '2025',
        },
      ],
    },
    contact: {
      title: 'Get In Touch',
      subtitle: 'I\'m always open to discussing new opportunities. Feel free to reach out!',
      form: {
        name: 'Your Name',
        email: 'Your Email',
        message: 'Your Message',
        send: 'Send Message',
        sending: 'Sending...',
        success: 'Message sent successfully!',
        error: 'Failed to send. Please try again.',
      },
      phone: '+91 9391219891',
      email: 'jaidheep333@gmail.com',
      linkedin: 'www.linkedin.com/in/dasari-jaidheep-111169257',
      github: 'github.com/Jaidheep7',
      instagram: 'www.instagram.com/d.jaidheep',
    },
    footer: {
      text: '© 2026 Dasari Jaidheep. Crafted with care.',
    },
  },
  jp: {
    nav: {
      home: 'ホーム',
      experience: '経歴',
      projects: 'プロジェクト',
      skills: 'スキル',
      languages: '言語能力',
      achievements: '実績・資格',
      contact: 'お問い合わせ',
      resume: '履歴書',
    },
    hero: {
      greeting: 'はじめまして',
      name: 'ダサリ ジャイディープ',
      tagline: 'AI・ML愛好家 | フルスタックWeb開発者',
      subtitle: 'SRM大学AP校のコンピューターサイエンス学部生。人工知能、機械学習、そしてエレガントなWebエクスペリエンスの構築に情熱を注いでいます。日本の革新的なチームへの貢献を目指しています。',
      downloadResume: '履歴書をダウンロード',
      resumePath: '/resumes/resume_jp.pdf',
    },
    experience: {
      title: '経歴',
      items: [
        {
          company: 'SRM大学AP校',
          role: 'リサーチインターン',
          duration: '2025年7月 — 現在',
          responsibilities: [
            '指導教員のもと、グラフニューラルネットワーク（GNN）を用いたソーシャルネットワーク分析に取り組む',
            'ノード間の関係性やネットワークの挙動に関する研究を実施',
            '小規模な研究チームで協力し、分析と実装に貢献',
          ],
        },
        {
          company: 'InternPe',
          role: 'Web開発インターン',
          duration: '2023年11月 — 2023年12月',
          responsibilities: [
            'HTMLとCSSを使用してレスポンシブなWebページを設計・開発',
            'UI/UXとウェブサイトの機能を改善',
            '実務レベルのフロントエンド開発の実践的な経験を獲得',
          ],
        },
        {
          company: 'ISKCONヴィジャヤワダ',
          role: 'ソーシャルインパクトインターン',
          duration: '2025年3月',
          responsibilities: [
            '持続可能性に焦点を当てたコミュニティ啓発プログラムに参加',
            '地域社会と交流し、社会的責任の取り組みに貢献',
          ],
        },
        {
          company: 'SRM大学AP校',
          role: 'コミュニティエンゲージメントプロジェクトリーダー',
          duration: '2023年1月',
          responsibilities: [
            '4人のチームを率いて、地元工場の実際の問題を特定し解決',
            'チームワーク、リーダーシップ、実践的な問題解決に注力',
          ],
        },
      ],
    },
    projects: {
      title: 'プロジェクト',
      items: [
        {
          title: 'GNNを用いたソーシャルネットワーク分析',
          description: '複雑なソーシャルネットワークの分析に焦点を当てた研究プロジェクト。グラフニューラルネットワークを応用し、ネットワークデータ内の関係性やパターンを研究。',
          techStack: ['Python', 'Graph Neural Networks', 'NetworkX', 'PyTorch'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: '支出管理Webアプリケーション',
          description: '支出追跡と予算管理のためのWebアプリケーション。支出記録、予算分析、データ可視化、セキュア認証、レスポンシブデザインを実装。',
          techStack: ['React.js', 'Node.js', 'MongoDB', 'JavaScript', 'CSS'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: 'レシピ管理プラットフォーム',
          description: '料理レシピの探索、共有、管理のためのWebプラットフォーム。食材、料理ジャンル、食事制限に基づくレシピの検索・フィルタリングを実現。',
          techStack: ['HTML', 'CSS', 'JavaScript', 'Node.js', 'MySQL'],
          github: 'https://github.com/Jaidheep7',
        },
        {
          title: '図書館管理システム',
          description: '図書館の蔵書管理および貸出・返却を追跡するシステム。書籍の在庫状況と利用状況のリアルタイム記録を維持。',
          techStack: ['Python', 'MySQL', 'HTML', 'CSS'],
          github: 'https://github.com/Jaidheep7',
        },
      ],
    },
    skills: {
      title: 'スキル',
      categories: [
        {
          name: 'プログラミング言語',
          items: ['Python', 'C', 'C++'],
        },
        {
          name: 'Web・データベース技術',
          items: ['HTML', 'CSS', 'JavaScript', 'React.js', 'Node.js', 'MongoDB', 'MySQL'],
        },
        {
          name: 'AI・関連技術',
          items: ['機械学習', 'コンピュータビジョン', 'グラフニューラルネットワーク（GNN）'],
        },
        {
          name: 'ツール・プラットフォーム',
          items: ['Git', 'Linux'],
        },
      ],
    },
    languages: {
      title: '言語能力',
      items: [
        { name: '英語', level: '流暢', proficiency: 90 },
        { name: 'テルグ語', level: '母語', proficiency: 100 },
        { name: 'ヒンディー語', level: 'ビジネスレベル', proficiency: 80 },
        { name: '日本語', level: 'JLPT N4（目標：N3）', proficiency: 45 },
      ],
    },
    achievements: {
      title: '実績・資格',
      items: [
        {
          title: 'MongoDB認定アソシエイト開発者',
          organization: 'MongoDB University',
          date: '2025年',
        },
        {
          title: 'TOMIDAI Global SciFrontiersプログラム',
          organization: '富山大学（日本）',
          date: '2025年',
        },
        {
          title: 'Pythonを使ったプログラミングの楽しさ（NPTEL）',
          organization: 'IITマドラス',
          date: '2023年',
        },
        {
          title: '全国アーチェリー大会 — 第10位',
          organization: '全国大会',
          date: '2017年',
        },
        {
          title: '優秀証明書 — 全国オリンピアード',
          organization: 'アーンドラ・プラデーシュ州政府',
          date: '2014年',
        },
        {
          title: '大学オンラインゲーム大会 優勝',
          organization: 'SRM大学AP校',
          date: '2025年',
        },
      ],
    },
    contact: {
      title: 'お問い合わせ',
      subtitle: '新しい機会についてのお話をお待ちしております。お気軽にご連絡ください！',
      form: {
        name: 'お名前',
        email: 'メールアドレス',
        message: 'メッセージ',
        send: '送信する',
        sending: '送信中...',
        success: 'メッセージが送信されました！',
        error: '送信に失敗しました。もう一度お試しください。',
      },
      phone: '+91 9391219891',
      email: 'jaidheep333@gmail.com',
      linkedin: 'www.linkedin.com/in/dasari-jaidheep-111169257',
      github: 'github.com/Jaidheep7',
      instagram: 'www.instagram.com/d.jaidheep',
    },
    footer: {
      text: '© 2026 ダサリ ジャイディープ。心を込めて作りました。',
    },
  },
};

export default content;
